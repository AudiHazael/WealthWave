function Home() {
  return (
    <div className="container mt-5">
      <h1>Home Page</h1>
      <p>Welcome to your new project starter!</p>
    </div>
  )
}

export default Home