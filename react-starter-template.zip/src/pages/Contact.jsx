function Contact() {
  return (
    <div className="container mt-5">
      <h1>Contact Page</h1>
      <p>Get in touch with us!</p>
    </div>
  )
}

export default Contact