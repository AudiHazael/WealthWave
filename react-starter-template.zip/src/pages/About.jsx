function About() {
  return (
    <div className="container mt-5">
      <h1>About Page</h1>
      <p>Learn more about this project template!</p>
    </div>
  )
}

export default About